/*
 * RP Racing: power tuning — 4 upgrades (engine, gearbox, tyres, nitro) x levels 0-3 for every car, ONE universal model (parameters: cars.json -> power_tuning).
 * Pure functions: the game uses them for the physics of a race, the screens for prices and the class, scripts/tuning for checks.
 * The server (racing_service.py) mirrors prices one-to-one; scripts/tuning/out/tuning_table.json holds the golden numbers both sides are tested against.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory;
  else root.RRPowerTuning = factory;
})(typeof self !== "undefined" ? self : this, function createPowerTuning(cfg) {
  "use strict";
  const P = cfg.params, STOCK = cfg.stock, classes = cfg.classes;
  const UPG = ["engine", "gearbox", "tyres", "nitro"];
  const ORDER = classes.map((k) => k.l);
  const letter = (v) => (classes.find((k) => v < k.below) || classes[classes.length - 1]).l;
  const pi = (c) => Math.round((c.power * 0.45 + c.top * 0.35 + c.grip * 0.2) * 1000);
  const headroom = (c) => Math.max(P.headroom.min, Math.min(1, (P.headroom.pi_cap - pi(c)) / (P.headroom.pi_cap - P.headroom.pi_floor)));
  const bias = (c, k) => (c.tune && c.tune[k]) || 1;
  const tier = (c) => Math.pow(Math.max(c.price, P.price.ref_price_floor) / P.price.tier_reference_price, P.price.tier_exponent);
  const levelSeconds = (c, k, L) => P.expected_seconds_at_max[k] * headroom(c) * (P.progress[L] - P.progress[L - 1]) * bias(c, k);
  const levelPrice = (c, k, L) => { const r = P.price.round_to; return Math.round(P.price.coins_per_full_second * P.expected_seconds_at_max[k] * headroom(c) * bias(c, k) * tier(c) * P.price.level_share[L - 1] / r) * r; };
  const sum = (c, lv, f) => UPG.reduce((a, k) => { let s = 0; for (let L = 1; L <= ((lv && lv[k]) || 0); L++) s += f(c, k, L); return a + s; }, 0);
  const totalSeconds = (c, lv) => sum(c, lv, levelSeconds);
  const totalPrice = (c, lv) => sum(c, lv, levelPrice);
  const isTuned = (lv) => UPG.some((k) => ((lv && lv[k]) || 0) > 0);
  // the class after tuning: never more than one letter above the stock one
  function classAfter(c, lv) {
    const eff = Math.round(pi(c) + P.pi_per_second * totalSeconds(c, lv)), base = letter(pi(c)), free = letter(eff), cap = ORDER[Math.min(ORDER.length - 1, ORDER.indexOf(base) + P.class_cap)];
    return { pi_eff: eff, letter: ORDER.indexOf(free) > ORDER.indexOf(cap) ? cap : free, letter_free: free };
  }
  // the physics numbers of ONE car with the given levels: a copy of the car definition + the `phys` the engine reads (engine/physics.js)
  function tuned(c, lv) {
    const h = headroom(c), E = P.effects_at_max;
    const s = (k) => P.progress[(lv && lv[k]) || 0] * h * bias(c, k);
    const def = { ...c }, phys = {};
    def.power = c.power * (1 + E.engine.power_pct / 100 * s("engine"));
    def.win = c.win * (1 + E.gearbox.win_pct / 100 * s("gearbox"));
    phys.badShiftM = STOCK.badShiftM + E.gearbox.bad_shift_penalty_mult * s("gearbox");
    phys.perfectT = STOCK.perfectT + E.gearbox.perfect_boost_sec * s("gearbox");
    def.grip = c.grip + E.tyres.grip_add * s("tyres");
    phys.tractionDecay = STOCK.tractionDecay * (1 - E.tyres.traction_decay_cut_pct / 100 * s("tyres"));
    phys.nitroM = STOCK.nitroM + E.nitro.strength_add * s("nitro");
    phys.nitroT = STOCK.nitroT + E.nitro.duration_add_sec * s("nitro");
    return { def, phys: { ...STOCK, ...phys } };
  }
  return { UPG, pi, headroom, tier, levelSeconds, levelPrice, totalSeconds, totalPrice, isTuned, classAfter, tuned, letter };
});
