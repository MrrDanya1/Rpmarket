/*
 * RP Racing: the «Как играть» slides (one card per step: a picture, a title with a coloured second line, a short text, dots, back / continue).
 * Created by the game page: RRTutorial.create(D). The page hands it exactly D = { $, haptic, sfx, reportScreen } and gets { open, close } back; the card builds its own markup and keeps its own state.
 * The slides are DATA (SLIDES below): a picture, two title lines, a text and an accent colour; adding a step means adding one object.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory;
  else root.RRTutorial = factory;
})(typeof self !== "undefined" ? self : this, (function () {
  "use strict";
  const SLIDES = [
    { img: "tutorial/step1.webp", title: ["Выбери", "машину"], text: "Посмотри класс и характеристики машины. Готов к заезду? Нажми «В гонку».", accent: "176, 154, 255" },
    { img: "tutorial/step2.webp", title: ["Вызови", "соперника"], text: "Выбери в комнате игрока или бота и нажми «Вызвать».", accent: "176, 154, 255" },
    { img: "tutorial/step3.webp", title: ["Следи за шкалой", "и жми"], text: "Во время заезда следи за шкалой и нажимай «ЖМИ» в нужный момент.", accent: "86, 230, 150" },
    { img: "tutorial/step4.webp", title: ["Гоняй и получай", "награды"], text: "Получай XP за результаты заездов, поднимайся в рейтинге и борись за призы сезона.", accent: "255, 202, 84" },
  ];
  const ARROW = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
  const BACK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>';
  const CLOSE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>';
  function create(D, opts) {
    const { $ } = D;
    const BV = (opts && opts.version) || "";
    const el = document.createElement("div");
    el.id = "howto"; el.className = "overlay howto"; el.hidden = true; el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true");
    el.innerHTML = '<div class="ht-card"><div class="ht-top"><span>Как играть</span><button class="ht-x" type="button" aria-label="Закрыть">' + CLOSE + '</button></div>'
      + '<div class="ht-body"><div class="ht-pic"><img alt="" decoding="async"></div><h2 class="ht-title"><b></b><i></i></h2><p class="ht-text"></p></div>'
      + '<div class="ht-dots"></div><div class="ht-foot"><button class="ht-back" type="button" aria-label="Назад">' + BACK + '</button><button class="ht-next" type="button"><span>Продолжить</span>' + ARROW + '</button></div></div>';
    const host = $("tutorial") || document.getElementById("frame");
    host.parentNode.insertBefore(el, host);
    const q = (s) => el.querySelector(s);
    const st = { i: 0 };
    function paint() {
      const s = SLIDES[st.i], last = st.i === SLIDES.length - 1;
      el.style.setProperty("--ht", s.accent);
      const img = q(".ht-pic img"); img.src = s.img + (BV && s.img.indexOf("?") < 0 ? "?v=" + BV : "");
      q(".ht-title b").textContent = s.title[0]; q(".ht-title i").textContent = s.title[1];
      /* the title is always ONE line: a long one is set a little smaller */
      q(".ht-title").style.fontSize = Math.min(26, Math.floor(318 / ((s.title[0].length + s.title[1].length + 1) * 0.6)))  + "px"; q(".ht-text").textContent = s.text;
      q(".ht-dots").innerHTML = SLIDES.map((_, k) => '<span' + (k === st.i ? ' class="on"' : "") + "></span>").join("");
      q(".ht-back").hidden = st.i === 0;
      q(".ht-next span").textContent = last ? "В гараж" : "Продолжить";
    }
    function open(i) { st.i = Math.max(0, Math.min(SLIDES.length - 1, i || 0)); paint(); el.hidden = false; el.classList.remove("in"); void el.offsetWidth; el.classList.add("in"); if (D.reportScreen) D.reportScreen("tutorial"); }
    function close(done) { el.hidden = true; if (done) { try { localStorage.setItem("rrTutor", "1"); } catch (e) {} } if (D.reportScreen) D.reportScreen("garage"); }
    function go(d) { const n = st.i + d; if (n < 0) return; if (n >= SLIDES.length) { close(true); return; } st.i = n; paint(); const c = q(".ht-body"); c.classList.remove("swap"); void c.offsetWidth; c.classList.add("swap"); }
    q(".ht-x").addEventListener("click", () => close(true));
    q(".ht-next").addEventListener("click", () => { if (D.sfx && D.sfx.tap) D.sfx.tap(); go(1); });
    q(".ht-back").addEventListener("click", () => go(-1));
    let x0 = null;
    el.addEventListener("touchstart", (e) => { x0 = e.touches[0].clientX; }, { passive: true });
    el.addEventListener("touchend", (e) => { if (x0 === null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(dx) > 48) go(dx < 0 ? 1 : -1); }, { passive: true });
    return { open, close, slides: SLIDES };
  }
  return { create };
})());
