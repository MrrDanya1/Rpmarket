/*
 * RP Racing: pictures of cars built from layers (platform + paint through a mask + vinyl + rims + spoiler), for the garage, the VS screen and the road.
 * Canvas / image work only: no game state. `vq` adds the build number to a file address (the game passes its own).
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory;
  else root.RRCarRender = factory;
})(typeof self !== "undefined" ? self : this, function createCarRender(opts) {
  "use strict";
  const vq = opts.vq;
  const OPT_LAYERS = ["rimmask", "rimpaint", "rimmask_b", "rimpaint_b"];      // rendered by scripts/car_layers (render_rimpaint_all.sh + post_rimpaint.py): the rims painted like the body
  const LAYER_NAMES = ["base", "paintmask", "stripes", "shadow", "gloss", "rims_a", "rims_b", "sp_gt", "sp_gt_mask", "sp_duck", "sp_duck_mask"];
  const LAYERED = {};
  const mkCanvas = (w, h) => { const cv = document.createElement("canvas"); cv.width = w; cv.height = h; return cv; };
  // the rims of a tune: «a» / «b» are the two RENDERED rim sets of the car (real spokes, light and shadows); «a@#rrggbb» is the same rendered set recoloured:
  // inside the wheel face (the ellipses are in the manifest «wheels», measured by scripts/car_layers/wheel_ellipses.py) the metal is repainted keeping its own shading, the dark gaps and the red brake calipers stay.
  const rimParts = (rims) => { const [d, col] = String(rims || "a").split("@"); return { design: d === "b" ? "b" : "a", color: /^#[0-9a-f]{6}$/i.test(col || "") ? col.toLowerCase() : "" }; };
  function tintRims(S, design, color) {
    S.rimCache = S.rimCache || {}; const key = design + color; if (S.rimCache[key]) return S.rimCache[key];
    const src = S.img["rims_" + design], cv = mkCanvas(S.w, S.h), g = cv.getContext("2d"); g.drawImage(src, 0, 0);
    if (S.wheels) {
      const im = g.getImageData(0, 0, S.w, S.h), d = im.data, n = parseInt(color.slice(1), 16), R = (n >> 16) & 255, G = (n >> 8) & 255, B = n & 255;
      for (const e of S.wheels) {
        const c = Math.cos(e.ang), s = Math.sin(e.ang), ka = 0.66 * (e.k || 1), x0 = Math.max(0, Math.floor(e.cx - e.a)), x1 = Math.min(S.w - 1, Math.ceil(e.cx + e.a)), y0 = Math.max(0, Math.floor(e.cy - e.a)), y1 = Math.min(S.h - 1, Math.ceil(e.cy + e.a)), hist = new Uint32Array(256), idx = [];
        for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) { const u = ((x - e.cx) * c + (y - e.cy) * s) / (e.a * ka), v = (-(x - e.cx) * s + (y - e.cy) * c) / (e.b * ka), i = (y * S.w + x) * 4; if (u * u + v * v <= 1 && d[i + 3] > 40) { idx.push(i, Math.sqrt(u * u + v * v)); hist[Math.min(255, Math.round(0.3 * d[i] + 0.59 * d[i + 1] + 0.11 * d[i + 2]))]++; } }
        let tot = idx.length / 2, acc = 0, lo = 0, hi = 255; for (let k = 0; k < 256; k++) { acc += hist[k]; if (acc >= tot * 0.05) { lo = k; break; } } acc = 0; for (let k = 255; k >= 0; k--) { acc += hist[k]; if (acc >= tot * 0.05) { hi = k; break; } }
        const flat = hi - lo < 70;      // an evenly dark rim (black spokes on a transparent layer): all its metal is repainted, shaded by its own light
        if (flat) { lo = 0; hi = Math.max(hi * 1.12, 40); } else if (hi - lo < 24) hi = lo + 24;
        for (let q = 0; q < idx.length; q += 2) {
          const i = idx[q], rr = idx[q + 1], r = d[i], gg = d[i + 1], b = d[i + 2];
          if (r > 1.5 * gg && r > 1.5 * b && r > 90) continue;      // a red brake caliper
          const l = Math.max(0, Math.min(1, ((0.3 * r + 0.59 * gg + 0.11 * b) - lo) / (hi - lo))), edge = Math.max(0, Math.min(1, (1 - rr) / 0.08));
          const w = edge;      // the whole face is painted, the dark barrel between the spokes too (in a deep shade of the colour), like in the old Forsage
          // a painted metal: the body colour in the mid-tones, the shadows go deep (not black), the sharp highlights turn towards white (a clear-coat glint); the original light of the render drives all of it
          const lm = Math.pow(l, 1.15), spec = Math.max(0, (l - 0.72) / 0.28), sh = 0.78 + 0.5 * lm, sp = spec * spec * 0.45;
          const tr = Math.min(255, R * sh) + (255 - Math.min(255, R * sh)) * sp, tg = Math.min(255, G * sh) + (255 - Math.min(255, G * sh)) * sp, tb = Math.min(255, B * sh) + (255 - Math.min(255, B * sh)) * sp;
          d[i] = r + (tr - r) * w; d[i + 1] = gg + (tg - gg) * w; d[i + 2] = b + (tb - b) * w;
        }
      }
      g.putImageData(im, 0, 0);
    }
    return (S.rimCache[key] = cv);
  }
  function drawRims(n, L, S, rims) {
    const { design, color } = rimParts(rims);
    if (!color) { n.drawImage(L["rims_" + design], 0, 0); return; }
    const suf = design === "b" ? "_b" : "", mask = L["rimmask" + suf], paint = L["rimpaint" + suf];
    if (mask && paint) {      // the rendered way: the neutral metal rims are tinted through the rim mask exactly like the body paint (the light, the shadows and the spokes are the render's own; the tyre and the brakes are not touched)
      S.rimCache = S.rimCache || {}; const key = "p" + design + color; let cv = S.rimCache[key];
      if (!cv) { cv = mkCanvas(S.w, S.h); const T = mkCanvas(S.w, S.h), g = cv.getContext("2d"); tintLayer(T, paint, mask, color); g.drawImage(paint, 0, 0); g.drawImage(T, 0, 0); g.globalCompositeOperation = "lighter"; g.globalAlpha = 0.18; g.drawImage(T, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = "source-over"; S.rimCache[key] = cv; }
      n.drawImage(cv, 0, 0); return;
    }
    n.drawImage(tintRims(S, design, color), 0, 0);
  }
  function loadLayered(c) {
    if (LAYERED[c.id]) return LAYERED[c.id];
    return (LAYERED[c.id] = (async () => {
      const man = await (await fetch(vq(c.layers + "manifest.json"))).json(), S = { w: man.w, h: man.h, ground: man.ground || man.h, carw: man.carw || man.w, cx: man.cx || man.w / 2, cy: man.cy || (man.ground || man.h) * 0.6, wheels: man.wheels || null, img: {}, key: "", skey: "" };
      await Promise.all([...LAYER_NAMES.map(async (n) => { S.img[n] = await createImageBitmap(await (await fetch(vq(`${c.layers}${n}.webp`))).blob()); }),
        ...OPT_LAYERS.map(async (n) => { try { const r = await fetch(vq(`${c.layers}${n}.webp`)); S.img[n] = r.ok ? await createImageBitmap(await r.blob()) : null; } catch (e) { S.img[n] = null; } })]);      // all layers at once (the rim paint ones used to wait for the first group)      // the rim paint layers are optional: a car without them keeps the pixel recolouring
      ["N", "M", "T", "S", "F"].forEach((k) => { S[k] = mkCanvas(S.w, S.h); });
      S.refH = Math.round(S.h * 0.5); S.R = mkCanvas(S.w, S.refH);
      return S;
    })());
  }
  function tintLayer(dst, src, mask, color) {
    const d = dst.getContext("2d"); d.globalCompositeOperation = "source-over"; d.clearRect(0, 0, dst.width, dst.height);
    d.drawImage(src, 0, 0); d.globalCompositeOperation = "multiply"; d.fillStyle = color; d.fillRect(0, 0, dst.width, dst.height);
    d.globalCompositeOperation = "destination-in"; d.drawImage(mask, 0, 0); d.globalCompositeOperation = "source-over";
  }
  // ----- the race view (straight down) of the same cars: built from the same kind of layers, so the paint / vinyl / spoiler fitted in the garage (or by the rival) show on the road -----
  const TOP_NAMES = ["base", "paintmask", "stripes", "shadow", "rims_a", "sp_gt", "sp_gt_mask", "sp_duck", "sp_duck_mask"], TOP_REF = 666;      // TOP_REF: the Priora's length in render pixels = 68 px on the road
  const TOPS = {}, TOPREADY = {}, TOPCV = new Map();
  function loadTop(c) {
    if (!c.topv) return null;
    if (TOPS[c.id]) return TOPS[c.id];
    return (TOPS[c.id] = (async () => {
      const man = await (await fetch(vq(c.topv + "manifest.json"))).json(), S = { w: man.w, h: man.h, h0: man.h0 || man.h, img: {} };
      await Promise.all(TOP_NAMES.map(async (n) => { S.img[n] = await createImageBitmap(await (await fetch(vq(`${c.topv}${n}.webp`))).blob()); }));
      ["N", "M", "T", "S"].forEach((k) => { S[k] = mkCanvas(S.w, S.h); });
      TOPREADY[c.id] = S; return S;
    })().catch(() => { delete TOPS[c.id]; return null; }));
  }
  // the picture of a car with its tune (paint / vinyl / rims / spoiler) for the VS screen: composed from the garage layers, cropped to the car; the stock thumbnail shows first
  async function tunedPicture(c, t) {
    if (!c.layers) return null;
    const S = await loadLayered(c), w = S.w, h = S.h, mk = () => mkCanvas(w, h), L = S.img;
    const N = mk(), M = mk(), T = mk(), ST = mk(), F = mk(), n = N.getContext("2d"), m = M.getContext("2d"), f = F.getContext("2d");
    n.drawImage(L.base, 0, 0); drawRims(n, L, S, t.rims); m.drawImage(L.paintmask, 0, 0);
    if (t.spoiler !== "none" && L["sp_" + t.spoiler]) { n.drawImage(L["sp_" + t.spoiler], 0, 0); m.drawImage(L["sp_" + t.spoiler + "_mask"], 0, 0); }
    tintLayer(T, N, M, t.paint); f.drawImage(N, 0, 0); f.drawImage(T, 0, 0);
    f.globalCompositeOperation = "lighter"; f.globalAlpha = 0.3; f.drawImage(T, 0, 0); f.globalAlpha = 1; f.globalCompositeOperation = "source-over";
    if (t.stripes) { tintLayer(ST, N, L.stripes, t.stripeColor); f.drawImage(ST, 0, 0); }
    const d = f.getImageData(0, 0, w, h).data; let x0 = w, x1 = 0, y0 = h, y1 = 0;
    for (let y = 0; y < h; y += 2) for (let x = 0; x < w; x += 2) if (d[(y * w + x) * 4 + 3] > 24) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 <= x0) return null;
    const out = mkCanvas(x1 - x0 + 8, y1 - y0 + 8); out.getContext("2d").drawImage(F, x0 - 4, y0 - 4, out.width, out.height, 0, 0, out.width, out.height);
    return out.toDataURL("image/png");
  }
  function showCarPicture(img, c, t, token) {
    img.src = vq(c.thumb || c.hi || ""); img.dataset.tok = token;
    tunedPicture(c, t).then((u) => { if (u && img.dataset.tok === token) img.src = u; }).catch(() => {});
  }
  const tuneKey = (c, t) => c.id + "|" + t.paint + "|" + (t.stripes ? t.stripeColor : "-") + "|" + t.spoiler;
  function topCanvas(c, t) {          // the finished car for one tune (cached); null until its layers are loaded
    const S = TOPREADY[c.id]; if (!S) { loadTop(c); return null; }
    const key = tuneKey(c, t); let cv = TOPCV.get(key); if (cv) return cv;
    const n = S.N.getContext("2d"), m = S.M.getContext("2d");
    n.clearRect(0, 0, S.w, S.h); n.drawImage(S.img.base, 0, 0, S.w, S.h); n.drawImage(S.img.rims_a, 0, 0, S.w, S.h);
    m.clearRect(0, 0, S.w, S.h); m.drawImage(S.img.paintmask, 0, 0, S.w, S.h);
    if (t.spoiler !== "none" && S.img["sp_" + t.spoiler]) { n.drawImage(S.img["sp_" + t.spoiler], 0, 0, S.w, S.h); m.drawImage(S.img["sp_" + t.spoiler + "_mask"], 0, 0, S.w, S.h); }
    tintLayer(S.T, S.N, S.M, t.paint);
    cv = mkCanvas(S.w, S.h); const f = cv.getContext("2d"); f.drawImage(S.N, 0, 0); f.drawImage(S.T, 0, 0);
    f.globalCompositeOperation = "lighter"; f.globalAlpha = 0.3; f.drawImage(S.T, 0, 0); f.globalAlpha = 1; f.globalCompositeOperation = "source-over";
    if (t.stripes) { tintLayer(S.S, S.N, S.img.stripes, t.stripeColor); f.drawImage(S.S, 0, 0); }
    cv.h0 = S.h0; cv.shadow = S.img.shadow;
    if (TOPCV.size > 24) TOPCV.delete(TOPCV.keys().next().value);
    TOPCV.set(key, cv); return cv;
  }

  const TUNE_DEFAULT = { stripes: false, stripeColor: "#ffffff", rims: "a", spoiler: "none" };
  return { drawRims, rimParts, LAYER_NAMES, TOP_REF, TUNE_DEFAULT, mkCanvas, tintLayer, loadLayered, loadTop, tunedPicture, showCarPicture, topCanvas, tuneKey };
});
