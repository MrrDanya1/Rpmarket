/*
 * RP Racing: tuning parts of the look (paint / vinyl / rims / spoiler): which parts a tune contains and what they cost.
 * Pure functions over the `tuning` block of cars/cars.json (the server charges by the same file). The place for the power-tuning parts to join.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory;
  else root.RRTuningParts = factory;
})(typeof self !== "undefined" ? self : this, function createTuningParts(TUNING) {
  "use strict";
  // rims is «design» or «design@#rrggbb» (the colour of a painted design): the design and the colour are two parts (the colour is «rimcolor:#rrggbb»)
  const rimSplit = (r) => { const [d, col] = String(r || "").split("@"); return { design: d, color: col ? col.toLowerCase() : "" }; };
  const partsOf = (c, t) => { const o = []; if ((t.paint || "").toLowerCase() !== c.color.toLowerCase()) o.push("paint:" + t.paint.toLowerCase()); if (t.stripes) o.push("stripes"); const r = rimSplit(t.rims); if (r.design !== TUNING.stock.rims) o.push("rims:" + r.design); if (r.color) o.push("rimcolor:" + r.color); if (t.spoiler !== TUNING.stock.spoiler) o.push("spoiler:" + t.spoiler); return o; };
  const partPrice = (c, part) => { const ov = TUNING.overrides || {}, kind = part.split(":")[0], id = String(c.id), model = id.split("#")[0], cars = model === id ? [id] : [id, model];
    for (const k of cars.map((x) => x + ":" + part).concat([part], cars.map((x) => x + ":" + kind))) if (k in ov) return Number(ov[k]) || 0;      // exact part of the car, exact part, the kind of the car, the kind
    return Number((TUNING.prices || {})[kind]) || 0; };
  return { partsOf, partPrice, rimSplit };
});
