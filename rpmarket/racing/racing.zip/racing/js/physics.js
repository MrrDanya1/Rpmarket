/*
 * RP Racing: the engine of a race (car state, shifting, one physics step, launch, replay of a list of presses).
 * No access to the screen, the clock or the network: the game (racing/index.html) and the tuning calculators (scripts/tuning) load this same file.
 * The tunable numbers live in `STOCK`; a car may carry its own `phys` (a tuning level), otherwise the stock values are used.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.RRPhysics = api;
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";
  const DIST = 402;                         // metres (a quarter mile)
  const VMAX = [62, 104, 146, 188, 230, 272];
  const A_G = [13.0, 10.6, 8.4, 6.7, 5.4, 4.4].map((x) => x * 0.62);
  const REDLINE = 8000, IDLE = 1800;
  const GREEN_FROM = 6900, GREEN_TO = 7700, GOOD_FROM = 6300;
  const STEP = 1 / 120;
  const TORQUE = [[1800, 0.60], [3000, 0.78], [4500, 0.95], [5500, 1.0], [7000, 1.0], [7700, 0.93], [8000, 0.80]];
  const torque = (r) => { for (let i = 0; i < TORQUE.length - 1; i++) { const [r0, t0] = TORQUE[i], [r1, t1] = TORQUE[i + 1]; if (r <= r1) return t0 + (t1 - t0) * (Math.max(r, r0) - r0) / (r1 - r0); } return 0.8; };
  const rpmOf = (v, g, top = 1) => Math.max(IDLE, (v * 3.6) / (VMAX[g] * top) * REDLINE);

  // the numbers that are constants in the game today (stock values); a tuning level changes some of them for ONE car
  const STOCK = { nitroM: 1.5, nitroT: 3.0, badShiftM: 0.75, badShiftT: 0.8, badShiftV: 0.985, tractionDecay: 0.35, perfectM: 1.35, perfectT: 1.2 };

  function newCar(def, color, glow, lane, phys) {
    const c = { def, name: def.name, color, glow, lane, s: 0, v: 0, g: 0, rpm: IDLE, boostT: 0, boostM: 1, nitroLeft: (phys || STOCK).nitroT, nitroUsed: false, nitroOn: false,
                perfect: 0, shifts: 0, topKmh: 0, finishT: null, lastQ: "", launched: false, launchAt: null, reaction: null, fs: false, startQ: "" };
    if (phys) c.phys = phys;
    return c;
  }
  function shiftUp(c) {
    if (c.g >= 5 || c.finishT !== null) return null;
    const P = c.phys || STOCK;
    const r = c.rpm; let q = "early";
    const mid = (GREEN_FROM + GREEN_TO) / 2, half = (GREEN_TO - GREEN_FROM) / 2 * c.def.win, gf = mid - half, gt = mid + half;
    if (r >= gf && r < gt) q = "perfect"; else if (r >= GOOD_FROM && r < gf) q = "good"; else if (r >= gt) q = "late";
    if (q === "perfect") { c.boostT = P.perfectT; c.boostM = P.perfectM; c.perfect++; }
    else if (q === "early" || q === "late") { c.boostT = P.badShiftT; c.boostM = P.badShiftM; c.v *= P.badShiftV; }
    c.g++; c.shifts++; c.rpm = rpmOf(c.v, c.g, c.def.top); c.lastQ = q;
    return q;
  }
  function stepCar(c, dt, now) {
    if (!c.launched) { c.rpm = IDLE; return; }
    if (c.finishT !== null) { c.v *= 0.9975; c.s += c.v * dt; c.rpm = rpmOf(c.v, c.g, c.def.top); return; }
    const P = c.phys || STOCK;
    c.rpm = rpmOf(c.v, c.g, c.def.top);
    let a = A_G[c.g] * c.def.power * torque(c.rpm);
    if (c.traction > 1) { a *= c.traction; c.traction -= dt * P.tractionDecay; }      // extra grip right after the launch
    if (c.boostT > 0) { a *= c.boostM; c.boostT -= dt; }
    if (c.rpm >= REDLINE - 5) a *= 0.15;
    if (c.nitroOn) { a *= P.nitroM; c.nitroLeft -= dt; if (c.nitroLeft <= 0) { c.nitroOn = false; c.nitroLeft = 0; } }
    a -= 0.00055 * c.v * c.v;
    c.v = Math.max(0, c.v + a * dt); c.s += c.v * dt; c.topKmh = Math.max(c.topKmh, c.v * 3.6);
    if (c.s >= DIST && c.finishT === null) c.finishT = now - (c.s - DIST) / Math.max(c.v, 1);
  }
  function useNitro(c) { if (c.nitroUsed || c.finishT !== null) return false; c.nitroUsed = true; c.nitroOn = true; return true; }

  // the start: reaction after the green light decides the launch. Returns the quality: "great" | "ok" | "slow" (fs = false start)
  function launch(c, r, fs, now) {
    c.launched = true; c.reaction = r; c.launchedAt = now; c.traction = c.def.grip;
    let q = "ok";
    if (!fs) { if (r < 0.22) { q = "great"; c.boostT = 1.1; c.boostM = 1.3; } else if (r > 0.5) { q = "slow"; c.boostT = 0.9; c.boostM = 0.8; } }
    c.startQ = fs ? "fs" : q;
    return q;
  }

  // a car's race as a function of its presses: events {k, a}, k = step after the green light, a = s (shift / launch press), n (nitro), f (false start).
  // The live loop applies the player's presses in exactly this order, so a replay gives the same car, bit for bit.
  function ghostNew(def, events, color, glow, lane, phys) {
    const c = newCar(def, color, glow, lane, phys);
    if (events.some((e) => e.a === "f")) { c.fs = true; c.launchAt = 1.0; }
    return { car: c, k: 0, t: 0, events };
  }
  function ghostStep(g) {
    const c = g.car; g.k++; g.t += STEP;
    for (const e of g.events) if (e.k === g.k && e.a === "s") { if (!c.launched) { if (!c.fs) launch(c, g.t, false, g.t); } else shiftUp(c); }
    if (!c.launched) { if (c.fs && g.t >= c.launchAt) launch(c, c.launchAt, true, g.t); else if (!c.fs && g.t >= 1.2) launch(c, 1.2, false, g.t); }
    for (const e of g.events) if (e.k === g.k && e.a === "n" && c.launched) useNitro(c);
    stepCar(c, STEP, g.t);
  }
  function ghostReplay(def, events, steps, phys) { const g = ghostNew(def, events, "#fff", "255,255,255", 0, phys); for (let i = 0; i < steps; i++) ghostStep(g); return g.car; }

  return { DIST, VMAX, A_G, REDLINE, IDLE, GREEN_FROM, GREEN_TO, GOOD_FROM, STEP, TORQUE, STOCK, torque, rpmOf, newCar, shiftUp, stepCar, useNitro, launch, ghostNew, ghostStep, ghostReplay };
});
